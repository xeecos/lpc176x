//#ifdef TARGET_LPC1768

/**
 * Copyright (C), 2020-2022, MakeBlock
 * @brief   Save the LOG file to the usb flash drive.
 * @file    log_to_file.cpp
 * @author  Liuwen
 * @version V1.0.0
 * @date    2020/05/11
 *
 */

#include <Print.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cstring>

#include "../../system/CMSIS/lib/usb_host/filesystems/fatfs/src/ff.h"
#include "Arduino.h"

#if DEBUG_LOG_TO_USB

#define LOG_FILE_SIZE_MAX (2097152) // 2*1024*1024

char log_file_name[16]={"mklog.txt"};
char log_file_isopen = 0;
FIL log_file_fp;


static void remove_file(void)
{
	FILINFO fno;
	FRESULT rc;

	// f_unmount("/");
	// f_mount(&fatFS, "/" , 0);

	FRESULT f_result = f_stat(log_file_name, &fno);
	if(f_result){
		return;
	} else {
		rc = f_unlink(log_file_name);
		if (rc){
			//FM_PRINTF("log file f_unlink(%d)\n", rc);
		}
	}
}

void open_log_file(bool ismount)
{
	if(ismount){
		if(log_file_isopen == 1)return;
		log_file_isopen = 1;
		FILINFO fno;
		f_stat(log_file_name, &fno);
		if(fno.fsize > LOG_FILE_SIZE_MAX){
			remove_file();
			fno.fsize = 0; // 否则会出现一大串乱码
		}
		FRESULT f_result = f_open(&log_file_fp, log_file_name, FA_READ | FA_WRITE | FA_OPEN_ALWAYS);
		if(f_result == FR_OK){
			printf("=================open mklog.txt OK=================\r\n");// 调用Print.cpp中的printf()函数  MK_PRINT_ARDUINO_DBG
			f_lseek(&log_file_fp, fno.fsize);
		}
	} else {
		log_file_isopen = 0;
		FRESULT rc = f_close(&log_file_fp);
		if(rc){
			//FM_PRINTF("log file f_close(%d)\r\n", rc);
			return;
		}
	}
}



static void file_write(const char* str)
{
	if(log_file_isopen == 0){
		return;
	}
	UINT bw;
	FRESULT rc;
	rc = f_write(&log_file_fp, str, strlen(str), &bw);
	if (rc == FR_OK){
		f_sync(&log_file_fp);
	}
}


void log_write_file(const char* tag, const char* str)
{

	if(tag == NULL || str == NULL || log_file_isopen == 0){
		return;
	}

	
#if DEBUG_LOG_TIME
	char merge_str[256];
	char data_str[16];
	sprintf_P(data_str, "%ums ", (unsigned int)millis());
	strcpy_P(merge_str, data_str);
	strcat_P(merge_str, tag);
	strcat_P(merge_str, str);
	strcat_P(merge_str, "\n");
	file_write(merge_str);

#else
	file_write(str);
#endif

}

#if 0
static void refresh_file(void)
{
	FRESULT rc;
	FILINFO fno;

	rc = f_close(&log_file_fp);
	if(rc){
		//FM_PRINTF("log file f_close(%d)\r\n", rc);
		return;
	}
	log_file_isopen = 0;
	open_file();

	f_stat(log_file_name, &fno);
	f_lseek(&log_file_fp, fno.fsize);
}
#endif

#endif