#include <cstdint>

extern "C" {
  #include <LPC17xx.h>
}

#include <pinmapping.h>
#include <pwm.h>
#include "log_to_file.h"

 __attribute__ ((weak)) void SysTick_Callback() {}

extern void setup();
extern void loop();

extern "C" {
  volatile uint64_t _millis;

  uint32_t SysTick_Config(uint32_t ticks) {
    if (ticks > SysTick_LOAD_RELOAD_Msk) return 1;

    SysTick->LOAD = (ticks & SysTick_LOAD_RELOAD_Msk) - 1;        // Set reload register
    SysTick->VAL  = 0;                                            // Load the SysTick Counter Value
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;                      // Enable SysTick IRQ and SysTick Timer

    NVIC_SetPriority(SysTick_IRQn, NVIC_EncodePriority(0, 0, 0)); // Set Priority for Cortex-M3 System Interrupts
    return 0;
  }

  void SysTick_Handler(void) {
    ++_millis;
    SysTick_Callback();
  }

  // Runs after clock init and before global static constructors
  void SystemPostInit() {
    _millis = 0;                            // Initialise the millisecond counter value;
    SysTick_Config(SystemCoreClock / 1000); // Start millisecond global counter
  }
}

int main(void) {
  // initialise PWM timers

	
	pwm_init();
	MK_PRINT_ARDUINO_DBG(0, "==========1=============\r\n");

	setup();
	MK_PRINT_ARDUINO_DBG(0, "==========2=============\r\n");
	for (;;)loop();
}
