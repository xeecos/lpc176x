#ifndef DEF_GET_EVENT_h
#define DEF_GET_EVENT_h

/**
 * Copyright (C), 2020-2022, MakeBlock
 * @brief   Define the macro.
 * @file    DefEvent.h
 * @author  Liuwen
 * @version V1.0.0
 * @date    2020/05/11
 *
 */

#define DEBUG_LOG_TO_USB			0
#define DEBUG_LOG_TIME				0
#define DEBUG_LOG_ALL				0
#define LOG_RECV_BUF_MAX			256



#define EVENT_STATUS_FALSE			0
#define EVENT_STATUS_TRUE			1
#define EVENT_GET_UDISK_MOUNT		1


#define GCODE_SPEED_MAX				4400 // 4460-4480
#define GCODE_SPEED_PC_MAX			9000
#define GCODE_SPEED_CONVERSION		0.483 //(GCODE_SPEED_MAX/GCODE_SPEED_PC_MAX)
#endif // DEF_GET_EVENT_h

