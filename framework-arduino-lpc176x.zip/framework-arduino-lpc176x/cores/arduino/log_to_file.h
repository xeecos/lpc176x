//#ifdef TARGET_LPC1768

/**
 * Copyright (C), 2020-2022, MakeBlock
 * @brief   Save the LOG file to the usb flash drive.
 * @file    log_to_file.h
 * @author  Liuwen
 * @version V1.0.0
 * @date    2020/05/11
 *
 */

#ifndef _LOG_TO_FILE_H_
#define _LOG_TO_FILE_H_
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cstring>

#include "../../system/CMSIS/lib/usb_host/filesystems/fatfs/src/ff.h"
#include "Arduino.h"

#if DEBUG_LOG_TO_USB
extern void log_write_file(const char* tag, const char* str);
extern void open_log_file(bool ismount);

#else

#define log_write_file(tag, str)
#define open_log_file(ismount)
#endif


#endif
//#endif
